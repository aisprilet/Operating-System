#include "types.h"
#include "stat.h"
#include "user.h"

#define MSGSIZE 8
float variance;

void print_variance(float xx) {
    int beg = (int)(xx);
    int fin = (int)(xx * 100) - beg * 100;
    printf(1, "Variance of array for the file arr is %d.%d\n", beg, fin);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf(1, "Need type and input filename\n");
        exit();
    }

    char *filename;
    filename = argv[2];
    int type = atoi(argv[1]);
    printf(1, "Type is %d and filename is %s\n", type, filename);

    int tot_sum = 0;

    int size = 1000;
    short arr[size];
    char c;

    int fd = open(filename, 0);

    if (fd < 0) {
        printf(1, "Error opening file: %s\n", filename);
        exit();
    }

    for (int i = 0; i < size;) {
        int bytesRead = read(fd, &c, 1);

        if (bytesRead == 0) {
            break;
        }

        if (c < '0' || c > '9') {
            continue;
        }

        arr[i++] = c - '0';
    }

    close(fd);

    printf(1, "First element: %d\n", arr[0]);

    int noOfProcesses = 8;
    int pidParent = getpid();
    int i, j, cid;
    int elmForEachProc = size / noOfProcesses;
    void *partialSumP = (void *)malloc(MSGSIZE);
    void *pmsg = (void *)malloc(MSGSIZE);
    int partialSum = 0;

    if (type == 0) {
        for (i = 0; i < noOfProcesses; i++) {
            cid = fork();
            if (cid == 0) {
                int curStart = i * elmForEachProc;
                int curEnd = (i + 1) * elmForEachProc;
                partialSum = 0;
                for (j = curStart; j < curEnd; j++) {
                    partialSum += (int)arr[j];
                }

                // printf(1, "Partial sum = %d\n", partialSum);
                pmsg = (void *)(&partialSum);
                send(getpid(), pidParent, (void *)pmsg);
                exit();
            } else {
                wait();
                recv((void *)partialSumP);
                tot_sum += *(int *)partialSumP;
            }
        }
    } else {
        int noOfProcesses = 8;
        int pidParent = getpid();
        int i;
        void *pmsg = (void *)malloc(MSGSIZE);
        int partialSum = 0;
        int indexArr[noOfProcesses + 1];
        indexArr[0] = 0;
        indexArr[noOfProcesses] = size;
        int children[noOfProcesses];

        for (int i = 1; i < noOfProcesses; i++)
            indexArr[i] = indexArr[i - 1] + (size / noOfProcesses);

        for (int i = 0; i < noOfProcesses; i++) {
            int cid = fork();
            if (cid == 0) {
                wait();
                partialSum = 0;
                int curStart = indexArr[i];
                int curEnd = indexArr[i + 1];

                for (j = curStart; j < curEnd; j++) {
                    partialSum += (short)arr[j];
                     //printf(1,"Partial sum%d\n",partialSum);
                }

                pmsg = (void *)(&partialSum);
                send(getpid(), pidParent, (void *)pmsg);
                sleep(100 * (i + 1));

                void *mean = (void *)malloc(MSGSIZE);
                recv((void *)mean);

                float var = 0;
                int k;
                for (k = curStart; k < curEnd; k++) {
                    var += (arr[k] - *(float *)mean) * (arr[k] - *(float *)mean);
                }

                sleep(10 * (i + 1));

                void *ret_var = (void *)malloc(MSGSIZE);
                ret_var = (void *)(&var);
                send(getpid(), pidParent, (void *)ret_var);
                exit();
            } else {
                children[i] = cid;
            }
        }

        sleep(10);

        for (int i = 0; i < noOfProcesses; i++) {
            void *partialSumP1 = (void *)malloc(MSGSIZE);
            recv((void *)partialSumP1);
            tot_sum += *(short *)partialSumP1;
        }

        //printf(1, "%d \n", tot_sum);

        float p_mean = (float)tot_sum / size;
         //printf(1,"mean%f\n",p_mean);
        void *multi_msg = (void *)malloc(MSGSIZE);
        multi_msg = (void *)(&p_mean);

        send_multi(getpid(), children, (void *)multi_msg);

        void *get_var = (void *)malloc(MSGSIZE);
        int v_v = 0;

        for (i = 0; i < noOfProcesses; i++) {
            wait();
            recv((void *)get_var);
            sleep(100*(i+1));
            v_v += *(float *)get_var;
        }

        variance = v_v / (float)size;
         //printf(1,"variance%d\n",variance);
    }

    if (type == 0) {
        printf(1, "Sum of array for file %s is %d\n", filename, tot_sum);
    } else {
        print_variance(variance);
    }

    exit();
}