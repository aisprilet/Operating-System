
# The assignment is based on Xv6, a simple Unix-like teaching operating system.
- Xv6 is available at the following [link](https://pdos.csail.mit.edu/6.828/2018/xv6.html).
- Install Xv6 version 11.
- Instructions to build and install xv6 can be found [here](https://drive.google.com/file/d/17QRMrRb4hCM5Zz33amRGvb458OkXlxo7/view).
- We run Xv6 on QEMU virtual machine.


# The assignment has the following components:
- We needed to implement Earliest Deadline First and Rate Monotonic scheduling algorithms to enable the execution of real time jobs in xv6.
- For this, we also had to implement the following system calls:
  - int sys_sched_policy(int pid, int policy)
  - int sys_exec_time(int pid, int exec_time)
  - int sys_deadline(int pid, int deadline)
  - int sys_rate(int pid, int rate)
  
### The details can be found in [OS_A2_easy.pdf](https://github.com/Vinit-Chandak/ELL783-Operating-Systems/blob/main/Assignment%202/OS-A2-easy.pdf)

### My report can be found here: [Report](https://github.com/Vinit-Chandak/ELL783-Operating-Systems/blob/main/Assignment%202/A2_report.pdf)
